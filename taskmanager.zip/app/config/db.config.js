module.exports = {
  HOST: "tododb.ckjm9itiabf3.ap-south-1.rds.amazonaws.com",
  USER: "admin",
  PASSWORD: "todoadmin",
  DB: "todoDB"
};
